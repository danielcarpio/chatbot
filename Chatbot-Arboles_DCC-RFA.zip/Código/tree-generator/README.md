# tree-generator
This API create a classification tree from the file you upload using SKLearn
